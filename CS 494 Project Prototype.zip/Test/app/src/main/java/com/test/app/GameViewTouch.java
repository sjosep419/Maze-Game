package com.test.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;

public class GameViewTouch extends GestureOverlayView {
    private int width, height, lineWidth;
    private int mazeSizeX, mazeSizeY;
    float cellWidth, cellHeight;
    float totalCellWidth, totalCellHeight;
    private int mazeFinishX, mazeFinishY;
    private Maze maze;
    private Activity context;
    private Paint line, red, finish, ball, background;
    private GestureLibrary objGestureLib;

    @SuppressLint("ClickableViewAccessibility")
    public GameViewTouch(Context context, Maze maze) {
        super(context);
        this.context = (Activity)context;
        this.maze = maze;
        mazeFinishX = maze.getFinalX();
        mazeFinishY = maze.getFinalY();
        mazeSizeX = maze.getMazeWidth();
        mazeSizeY = maze.getMazeHeight();
        line = new Paint();
        line.setColor(getResources().getColor(R.color.line));
        red = new Paint();
        red.setColor(getResources().getColor(R.color.position));
        finish = new Paint();
        finish.setColor(getResources().getColor(R.color.finish));
        ball = new Paint();
        ball.setColor(getResources().getColor(R.color.teal_700));
        background = new Paint();
        background.setColor(getResources().getColor(R.color.game_bg));
        setFocusable(true);
        this.setFocusableInTouchMode(true);
        this.setOnTouchListener(new OnSwipeTouchListener(context) {
            boolean moved = false;
            @Override
            public void onSwipeDown() {
                System.out.println("DOWN");
                moved = maze.move(Maze.DOWN);
                checkIfDone(moved);
            }

            @Override
            public void onSwipeLeft() {
                System.out.println("LEFT");
                moved = maze.move(Maze.LEFT);
                checkIfDone(moved);
            }

            @Override
            public void onSwipeUp() {
                System.out.println("UP");
                moved = maze.move(Maze.UP);
                checkIfDone(moved);
            }

            @Override
            public void onSwipeRight() {
                System.out.println("RIGHT");
                moved = maze.move(Maze.RIGHT);
                checkIfDone(moved);
            }

        });
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
//        width = (w < h)?w:h;   //check whether the width or height of the screen is smaller
//        height = width;         //for now square mazes
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity)getContext()).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        width = displayMetrics.widthPixels - 150;
        height = displayMetrics.heightPixels;
        lineWidth = 1;          //for now 1 pixel wide walls
        cellWidth = (width - (float)(mazeSizeX*lineWidth)) / mazeSizeX;
        totalCellWidth = cellWidth+lineWidth;
        cellHeight = (height - ((float)mazeSizeY*lineWidth)) / mazeSizeY;
        totalCellHeight = cellHeight+lineWidth;
        red.setTextSize(cellHeight*0.75f);
        finish.setTextSize(cellHeight*0.75f);
        super.onSizeChanged(w, h, oldw, oldh);
    }

    protected void onDraw(Canvas canvas) {
        //fill in the background
        canvas.drawRect(0, 0, width + 150, height, background);

        boolean[][] vLines = maze.getVerticalLines();
        boolean[][] hLines = maze.getHorizontalLines();
        //iterate over the boolean arrays to draw walls

        for (int i = 0; i < vLines.length; i++) {
            for (int j = 0; j < vLines[0].length; j++) {
//                System.out.println("i, j:  " + i + " " + j);
                if (vLines[i][j]) {
                    float x = j * totalCellWidth;
                    float y = i * totalCellHeight;
                    canvas.drawLine(x + cellWidth,   //start X
                            y,               //start Y
                            x + cellWidth,   //stop X
                            y + cellHeight,  //stop Y
                            line);
                }
            }
        }


        for (int i = 0; i <  hLines.length; i++) {
            for (int j = 0; j < hLines[0].length; j++) {
//                System.out.println("i, j:  " + i + " " + j);
                if (hLines[i][j]) {
                    float x = j * totalCellWidth;
                    float y = i * totalCellHeight;
                    canvas.drawLine(x,               //startX
                            y + cellHeight,  //startY
                            x + cellWidth,   //stopX
                            y + cellHeight,  //stopY
                            line);
                }
            }
        }

        int currentX = maze.getCurrentX(),currentY = maze.getCurrentY();
        //draw the ball
        canvas.drawCircle((currentX * totalCellWidth)+(cellWidth/2),   //x of center
                (currentY * totalCellHeight)+(cellWidth/2),  //y of center
                (cellWidth*0.45f),                           //radius
                ball);

        //draw the finishing point indicator
        if (!maze.isPuzzleOneComplete()) {
            canvas.drawText("P",
                    (maze.getPuzzleX(1) * totalCellWidth) + (cellWidth * 0.25f),
                    (maze.getPuzzleY(1) * totalCellHeight) + (cellHeight * 0.75f),
                    red);
        }

        if (!maze.isPuzzleTwoComplete()) {
            canvas.drawText("P",
                    (maze.getPuzzleX(2) * totalCellWidth) + (cellWidth * 0.25f),
                    (maze.getPuzzleY(2) * totalCellHeight) + (cellHeight * 0.75f),
                    red);
        }

        //draw the finishing point indicator
        canvas.drawText("F",
                (mazeFinishX * totalCellWidth)+(cellWidth*0.25f),
                (mazeFinishY * totalCellHeight)+(cellHeight*0.75f),
                finish);
    }

    public void checkIfDone(boolean moved) {
        if (moved == true) {
            //the ball was moved so we'll redraw the view
            invalidate();
            if (maze.isGameComplete() && maze.isPuzzleOneComplete() && maze.isPuzzleTwoComplete()) {
                //game completed
                Intent intent = new Intent(context, FinalScreen.class);
                context.startActivity(intent);
                context.finish();

            } else if (maze.isPuzzle1() && !(maze.isPuzzleOneComplete())) {
                Intent intent = new Intent(context, puzzle1.class);
                intent.putExtra("maze", maze);                     //add the maze to the intent which we'll retrieve in the Maze Activity
                context.startActivity(intent);
                maze.setPuzzleOneComplete(true);

            } else if (maze.isPuzzle2() && !(maze.isPuzzleTwoComplete())) {
                Intent intent = new Intent(context, puzzle2.class);
                intent.putExtra("maze", maze);                     //add the maze to the intent which we'll retrieve in the Maze Activity
                context.startActivity(intent);
                maze.setPuzzleTwoComplete(true);
            }
        }
    }


}
