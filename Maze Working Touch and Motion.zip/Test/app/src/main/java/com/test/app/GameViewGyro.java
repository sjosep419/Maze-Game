package com.test.app;
import java.lang.Math;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorEventListener2;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;

public class GameViewGyro extends View implements SensorEventListener2 {
    private int width, height, lineWidth;
    private int mazeSizeX, mazeSizeY;
    float cellWidth, cellHeight;
    float totalCellWidth, totalCellHeight;
    private int mazeFinishX, mazeFinishY;
    private Maze maze;
    private Activity context;
    private Paint line, red, background;
    private Gyroscope gyroscope;
    private float xPos, xAccel, xVel = 0.0f;
    private float yPos, yAccel, yVel = 0.0f;
    private float xMax, yMax;
    private SensorManager sensorManager;
    private AlertDialog.Builder builder;
    private AlertDialog finishDialog;
    private View view;
    private View closeButton;
    private LayoutInflater inflater;
    private GameGyro gg;

    @SuppressLint("ClickableViewAccessibility")
    public GameViewGyro(Context context, Maze maze) {
        super(context);
        this.context = (Activity) context;
//        gg = new GameGyro();
//        builder = new AlertDialog.Builder(context);
//        builder.setTitle(context.getText(R.string.finished_title));
//        inflater = ((Activity) context).getLayoutInflater();
//        view = inflater.inflate(R.layout.finish, null);
//        closeButton = view.findViewById(R.id.closeGame);
//        builder.setView(view);
//        finishDialog = builder.create();
        this.maze = maze;
        mazeFinishX = maze.getFinalX();
        mazeFinishY = maze.getFinalY();
        mazeSizeX = maze.getMazeWidth();
        mazeSizeY = maze.getMazeHeight();
        line = new Paint();
        line.setColor(getResources().getColor(R.color.line));
        red = new Paint();
        red.setColor(getResources().getColor(R.color.position));
        background = new Paint();
        background.setColor(getResources().getColor(R.color.game_bg));
        setFocusable(true);
        this.setFocusableInTouchMode(true);
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_UI);

    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
//        width = (w < h)?w:h;   //check whether the width or height of the screen is smaller
//        height = width;         //for now square mazes
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity)getContext()).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        width = displayMetrics.widthPixels - 150;
        height = displayMetrics.heightPixels;
        lineWidth = 1;          //for now 1 pixel wide walls
        cellWidth = (width - (float)(mazeSizeX*lineWidth)) / mazeSizeX;
        totalCellWidth = cellWidth+lineWidth;
        cellHeight = (height - ((float)mazeSizeY*lineWidth)) / mazeSizeY;
        totalCellHeight = cellHeight+lineWidth;
        red.setTextSize(cellHeight*0.75f);
        super.onSizeChanged(w, h, oldw, oldh);
    }

    protected void onDraw(Canvas canvas) {
        //fill in the background
        canvas.drawRect(0, 0, width + 150, height, background);

        boolean[][] vLines = maze.getVerticalLines();
        boolean[][] hLines = maze.getHorizontalLines();
        //iterate over the boolean arrays to draw walls

        for (int i = 0; i < vLines.length; i++) {
            for (int j = 0; j < vLines[0].length; j++) {
//                System.out.println("i, j:  " + i + " " + j);
                if (vLines[i][j]) {
                    float x = j * totalCellWidth;
                    float y = i * totalCellHeight;
                    canvas.drawLine(x + cellWidth,   //start X
                            y,               //start Y
                            x + cellWidth,   //stop X
                            y + cellHeight,  //stop Y
                            line);
                }
            }
        }


        for (int i = 0; i <  hLines.length; i++) {
            for (int j = 0; j < hLines[0].length; j++) {
//                System.out.println("i, j:  " + i + " " + j);
                if (hLines[i][j]) {
                    float x = j * totalCellWidth;
                    float y = i * totalCellHeight;
                    canvas.drawLine(x,               //startX
                            y + cellHeight,  //startY
                            x + cellWidth,   //stopX
                            y + cellHeight,  //stopY
                            line);
                }
            }
        }

        int currentX = maze.getCurrentX(),currentY = maze.getCurrentY();
        //draw the ball
        canvas.drawCircle((currentX * totalCellWidth)+(cellWidth/2),   //x of center
                (currentY * totalCellHeight)+(cellWidth/2),  //y of center
                (cellWidth*0.45f),                           //radius
                red);

        if (!maze.isPuzzleOneComplete()) {
            canvas.drawText("P",
                    (maze.getPuzzleX(1) * totalCellWidth) + (cellWidth * 0.25f),
                    (maze.getPuzzleY(1) * totalCellHeight) + (cellHeight * 0.75f),
                    red);
        }

        if (!maze.isPuzzleTwoComplete()) {
            canvas.drawText("P",
                    (maze.getPuzzleX(2) * totalCellWidth) + (cellWidth * 0.25f),
                    (maze.getPuzzleY(2) * totalCellHeight) + (cellHeight * 0.75f),
                    red);
        }

        //draw the finishing point indicator
        canvas.drawText("F",
                (mazeFinishX * totalCellWidth)+(cellWidth*0.25f),
                (mazeFinishY * totalCellHeight)+(cellHeight*0.75f),
                red);
    }

    public void checkIfDone(boolean moved) {
        if (moved == true) {
            //the ball was moved so we'll redraw the view
            invalidate();
            if (maze.isGameComplete() && maze.isPuzzleOneComplete() && maze.isPuzzleTwoComplete()) {
                sensorManager.unregisterListener(this);
                Intent intent = new Intent(context, FinalScreen.class);
                context.startActivity(intent);
                context.finish();
            } else if (maze.isPuzzle1() && !(maze.isPuzzleOneComplete())) {
                Intent intent = new Intent(context, puzzle1.class);
                intent.putExtra("maze", maze);                     //add the maze to the intent which we'll retrieve in the Maze Activity
                sensorManager.unregisterListener(this);
                context.startActivity(intent);
                maze.setPuzzleOneComplete(true);
                sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_UI);
            } else if (maze.isPuzzle2() && !(maze.isPuzzleTwoComplete())) {
                Intent intent = new Intent(context, puzzle2.class);
                intent.putExtra("maze", maze);                     //add the maze to the intent which we'll retrieve in the Maze Activity
                sensorManager.unregisterListener(this);
                context.startActivity(intent);
                maze.setPuzzleTwoComplete(true);
                sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_UI);
            }
        }
    }

    @Override
    public void onFlushCompleted(Sensor sensor) {

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            xAccel = sensorEvent.values[0];
            yAccel = -sensorEvent.values[1];
            movePlayer();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    private void movePlayer() {
//        System.out.print("In Move Player");
        boolean moved = false;
        float frameTime = 0.66666f;
        xVel = (xAccel * frameTime);
        yVel = (yAccel * frameTime);
        float xS = (xVel / 2) * frameTime;
        float yS = (yVel / 2) * frameTime;

//        System.out.println(yS);
//        System.out.println(yAccel);
        if (yS > 0.6 && (Math.abs(yS) > xS)) {
            moved = maze.move(Maze.LEFT);
            System.out.println("GYRO LEFT");

        }
        else if (yS < -0.4 && (Math.abs(yS) > Math.abs(xS)) ) {
            moved = maze.move(Maze.RIGHT);
            System.out.println("GYRO RIGHT");

        }
        else if (xS > 0.4) {
//            System.out.println(yS);
            moved = maze.move(Maze.DOWN);
            System.out.println("GYRO DOWN");

        }
        else if (xS < -0.4) {
//            System.out.println(yS);
            moved = maze.move(Maze.UP);
            System.out.println("GYRO UP");

        }
        checkIfDone(moved);
    }
}
