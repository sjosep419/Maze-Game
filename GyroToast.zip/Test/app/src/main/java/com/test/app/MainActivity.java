// The underlaying Maze UI was implemented from the following citation:
// Zoopable. (n.d.). Zoopable. Retrieved October 27, 2022, from http://www.zoopable.com/android-game-programming-tutorial-mazeman/
// It was updated to fit our needs with the gestures, gyroscope, and puzzles (custom gesture)

package com.test.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;

import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;

public class MainActivity extends Activity {


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button touchGame = (Button)findViewById(R.id.touch);
        Button motionGame = (Button)findViewById(R.id.motion);

        touchGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button touched = (Button)view;
                Intent game = new Intent(MainActivity.this, GameTouch.class);  //create an Intent to launch the Game Activity
                Maze maze = MazeCreator.getMaze(1);         //use helper class for creating the Maze
                game.putExtra("maze", maze);                     //add the maze to the intent which we'll retrieve in the Maze Activity
                startActivity(game);
//                return true;
                }
        });

        motionGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button touched = (Button)view;
                Intent game = new Intent(MainActivity.this, GameGyro.class);  //create an Intent to launch the Game Activity
                Maze maze = MazeCreator.getMaze(1);         //use helper class for creating the Maze
                game.putExtra("maze", maze);                     //add the maze to the intent which we'll retrieve in the Maze Activity
                startActivity(game);
//                return true;
            }
        });
    }



}