package com.test.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class GameTouch extends Activity {

//    private GestureLibrary objGestureLib;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
//        setContentView(R.layout.levels);
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();    //get the intent extras
        Maze maze = (Maze)extras.get("maze");  //retrieve the maze from intent extras

        GameViewTouch view = new GameViewTouch(this, maze);


        setContentView(view);
    }

    public void finishIt() {
        this.finish();
    }

}

