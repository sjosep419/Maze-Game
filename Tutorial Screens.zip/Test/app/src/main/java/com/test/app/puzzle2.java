package com.test.app;


import android.app.Activity;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.gesture.Prediction;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import java.util.ArrayList;

public class puzzle2 extends AppCompatActivity implements OnGesturePerformedListener{

    private GestureLibrary objGestureLib;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.puzzle_2);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);  //day
        objGestureLib = GestureLibraries.fromRawResource(this, R.raw.gestures);

        if (!objGestureLib.load()) {
            finish();
        }

        GestureOverlayView objGestureOverlay = (GestureOverlayView) findViewById(R.id.WidgetGesture);
        objGestureOverlay.setGestureStrokeType(GestureOverlayView.GESTURE_STROKE_TYPE_MULTIPLE);
        objGestureOverlay.addOnGesturePerformedListener(this);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onGesturePerformed(GestureOverlayView gestureOverlayView, Gesture gesture) {

        ArrayList<Prediction> objPrediction = objGestureLib.recognize(gesture);
        if (objPrediction.size() > 0 && objPrediction.get(0).score > 1) {
            String gestureName = objPrediction.get(0).name;
            if (gestureName.charAt(0) == 'a') {
                Toast.makeText(this, "Puzzle Solved!", Toast.LENGTH_SHORT).show();
                this.finish();
            } else {
                Toast.makeText(this, "Try Again", Toast.LENGTH_SHORT).show();
            }
        }
    }
}