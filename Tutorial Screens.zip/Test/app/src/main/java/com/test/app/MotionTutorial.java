package com.test.app;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import pl.droidsonroids.gif.GifImageView;


public class MotionTutorial extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("HELLOOOO");
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);  //day
        setContentView(R.layout.motiontutorial);

        Button goGame = (Button)findViewById(R.id.tomotionGame);
        Button menu = (Button)findViewById(R.id.backButton2);
        GifImageView myView = findViewById(R.id.leftRightGIF);
        myView.setImageResource(R.drawable.giphy);
        GifImageView myView2 = findViewById(R.id.upDownGIF);
        myView2.setImageResource(R.drawable.giphy);

        goGame.setEnabled(false);

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                // This method will be executed once the timer is over
                goGame.setEnabled(true);

            }
        },5000);// set time as per your requirement

        goGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent game = new Intent(MotionTutorial.this, GameGyro.class);  //create an Intent to launch the Game Activity
                Maze maze = MazeCreator.getMaze(1);         //use helper class for creating the Maze
                game.putExtra("maze", maze);                     //add the maze to the intent which we'll retrieve in the Maze Activity
                startActivity(game);
//                finish();
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent = new Intent(MotionTutorial.this, MainActivity.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                startActivity(intent);
                finish();
            }
        });
        super.onCreate(savedInstanceState);
    }


}