package com.test.app;

import java.io.Serializable;

public class Maze implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final int UP = 0, DOWN = 1, RIGHT = 2, LEFT = 3;

    private boolean[][] verticalLines;
    private boolean[][] horizontalLines;
    private int sizeX, sizeY;         //stores the width and height of the maze
    private int currentX, currentY;   //stores the current location of the ball
    private int finalX, finalY;       //stores the finishing point of the maze
    private int puzzle1X, puzzle1Y;
    private int puzzle2X, puzzle2Y;
    private boolean gameComplete;
    private boolean puzzleOneComplete;
    private boolean puzzleTwoComplete;

    public int getPuzzleX(int puzzleNum) {
        if (puzzleNum == 1) {
            return puzzle1X;
        } else {
            return puzzle2X;
        }
    }

    public int getPuzzleY(int puzzleNum) {
        if (puzzleNum == 1) {
            return puzzle1Y;
        } else {
            return puzzle2Y;
        }
    }

    public int getFinalX() {
        return finalX;
    }

    public int getFinalY() {
        return finalY;
    }

    public int getMazeWidth() {
        return sizeX;
    }

    public int getMazeHeight() {
        return sizeY;
    }

    public boolean[][] getHorizontalLines() {
        return horizontalLines;
    }

    public boolean[][] getVerticalLines() {
        return verticalLines;
    }

    public int getCurrentX() {
        return currentX;
    }

    public int getCurrentY() {
        return currentY;
    }


    public boolean move(int direction) {
        boolean moved = false;
        if(direction == UP) {
            if(currentY != 0 && !horizontalLines[currentY-1][currentX]) {
                currentY--;
                moved = true;
            }
        }
        if(direction == DOWN) {
            if(currentY != sizeY-1 && !horizontalLines[currentY][currentX]) {
                currentY++;
                moved = true;
            }
        }
        if(direction == RIGHT) {
            System.out.println("current x: " + currentX);
            System.out.println("size x: " + sizeX);
            if(currentX != sizeX && !verticalLines[currentY][currentX]) {
                currentX++;
                moved = true;
            }
        }
        if(direction == LEFT) {
            if(currentX != 0 && !verticalLines[currentY][currentX-1]) {
                currentX--;
                moved = true;
            }
        }
        if(moved) {
            if(currentX == finalX && currentY == finalY) {
                gameComplete = true;
            }
        }
        return moved;
    }

    public boolean isGameComplete() {
        if (currentX == finalX && currentY == finalY) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isPuzzle1() {
        if (currentX == puzzle1X && currentY == puzzle1Y) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isPuzzle2() {
        if (currentX == puzzle2X && currentY == puzzle2Y) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isPuzzleOneComplete() {
        return puzzleOneComplete;
    }

    public boolean isPuzzleTwoComplete() {
        return puzzleTwoComplete;
    }

    public void setPuzzleOneComplete(boolean complete) {
        this.puzzleOneComplete = complete;
    }

    public void setPuzzleTwoComplete(boolean complete) {
        this.puzzleTwoComplete = complete;
    }

    public void setVerticalLines(boolean[][] vLines) {
        verticalLines = vLines;
        sizeY = vLines.length;
    }

    public void setHorizontalLines(boolean[][] hLines) {
        horizontalLines = hLines;
        sizeX = verticalLines[0].length;
    }

    public void setStartPosition(int i, int i1) {
        currentX = i;
        currentY = i1;
    }

    public void setFinalPosition(int i, int i1) {
        finalX = i;
        finalY = i1;
    }

    public void setPuzzlePos(int i, int i1, int puzzleNum) {
        if (puzzleNum == 1) {
            puzzle1X = i;
            puzzle1Y = i1;
        } else {
            puzzle2X = i;
            puzzle2Y = i1;
        }
    }

    //setters and getters
}
