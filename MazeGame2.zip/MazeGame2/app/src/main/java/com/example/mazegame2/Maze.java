package com.example.mazegame2;

import java.io.Serializable;

public class Maze implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final int UP = 0, DOWN = 1, RIGHT = 2, LEFT = 3;

    private boolean[][] verticalLines;
    private boolean[][] horizontalLines;
    private int sizeX, sizeY;         //stores the width and height of the maze
    private int currentX, currentY;   //stores the current location of the ball
    private int finalX, finalY;       //stores the finishing point of the maze
    private boolean gameComplete;

    public int getFinalX() {
        return finalX;
    }

    public int getFinalY() {
        return finalY;
    }

    public int getMazeWidth() {
        return sizeX;
    }

    public int getMazeHeight() {
        return sizeY;
    }

    public boolean[][] getHorizontalLines() {
        return horizontalLines;
    }

    public boolean[][] getVerticalLines() {
        return verticalLines;
    }

    public int getCurrentX() {
        return currentX;
    }

    public int getCurrentY() {
        return currentY;
    }


    //    public boolean move(int movement) {
//        // Up
//        if (movement == 0) {
//            if (verticalLines[currentX][currentY+1] == false && horizontalLines[currentX][currentY+1] == false) {
//                currentY = currentY + 1;
//                return true;
//            }
//        } else if (movement == 1) {
//            if (verticalLines[currentX][currentY-1] == false && horizontalLines[currentX][currentY-1] == false) {
//                currentY = currentY - 1;
//                return true;
//            }
//        } else if (movement == 2) {
//            if (verticalLines[currentX+1][currentY] == false && horizontalLines[currentX+1][currentY] == false) {
//                currentX = currentX + 1;
//                return true;
//            }
//        } else {
//            if (verticalLines[currentX-1][currentY] == false && horizontalLines[currentX-1][currentY] == false) {
//                currentX = currentX - 1;
//                return true;
//            }
//        }
//        return false;
//    }

    public boolean move(int direction) {
        boolean moved = false;
        if(direction == UP) {
            if(currentY != 0 && !horizontalLines[currentY-1][currentX]) {
                currentY--;
                moved = true;
            }
        }
        if(direction == DOWN) {
            if(currentY != sizeY-1 && !horizontalLines[currentY][currentX]) {
                currentY++;
                moved = true;
            }
        }
        if(direction == RIGHT) {
            System.out.println("current x: " + currentX);
            System.out.println("size x: " + sizeX);
            if(currentX != sizeX && !verticalLines[currentY][currentX]) {
                currentX++;
                moved = true;
            }
        }
        if(direction == LEFT) {
            if(currentX != 0 && !verticalLines[currentY][currentX-1]) {
                currentX--;
                moved = true;
            }
        }
        if(moved) {
            if(currentX == finalX && currentY == finalY) {
                gameComplete = true;
            }
        }
        return moved;
    }

    public boolean isGameComplete() {
        if (currentX == finalX && currentY == finalY) {
            return true;
        } else {
            return false;
        }
    }

    public void setVerticalLines(boolean[][] vLines) {
        verticalLines = vLines;
        sizeY = vLines.length;
    }

    public void setHorizontalLines(boolean[][] hLines) {
        horizontalLines = hLines;
        sizeX = verticalLines[0].length;
    }

    public void setStartPosition(int i, int i1) {
        currentX = i;
        currentY = i1;
    }

    public void setFinalPosition(int i, int i1) {
        finalX = i;
        finalY = i1;
    }


    //setters and getters
}
